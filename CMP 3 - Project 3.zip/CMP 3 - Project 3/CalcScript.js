
    const calculator = {
        displayValue: '0', // default value in display
        first: null,       // first operand
        wait: false,       // waiting period after operator is input before inputting second operand
        operator: null     // operator determining which kind of operation to be performed: +, -, *, /, =
    };

    function inputNumbers(number) {
        const displayValue = calculator.displayValue; // overwrite 'displayValue' if current value is 0 or otherwise append to it
        const wait = calculator.wait; // set wait to true if first operand is already input

        if(wait === true) {
            calculator.displayValue = number;
            calculator.wait = false;
        }
        else {
            calculator.displayValue = displayValue === '0' ? number : displayValue + number; // check if current value in display screen 
        // is zero using ternary operator '?'. Replace display value in calculator with the input digit
        }

        console.log(calculator);
    }

    function inputDecimal(point) {
        // if there is no decimal point in the display value, then include it
        if(!calculator.displayValue.includes(point)) {
            calculator.displayValue += point;
        }
    }

    function clearAll() { // clear all numbers in the calculator display and set variables to default values

        calculator.displayValue = '0'; // rest display value to '0' after clicking clear button
        calculator.first = null;
        calculator.wait = false;
        calculator.operator = null;
        console.log(calculator);
    }

    function operators(operator2) {

        // assign calculator properties' values
        const first = calculator.first;
        const displayValue = calculator.displayValue;
        const operator = calculator.operator;

        // displayValue string is converted to floating-point number with 'parseFloat'
        const inputValue = parseFloat(displayValue);

        if(first == null && inputValue !== NaN) {
            calculator.first = inputValue; // assign input to first operand
        }
        else if(operator) {
            const result = calculation(first, inputValue, operator);

            calculator.displayValue = String(result);
            calculator.first = result;
        }

        calculator.wait = true; // waiting for second operand after operator is input
        calculator.operator = operator2;

        console.log(calculator);
    }

    

    function calculation(first, second, operator) {
        let result; // declaring result, probably not necessary in this case 

        if(operator === '+') {
            result = first + second;
            return result;
        }
        else if(operator === '-') {
            result = first - second;
            return result;
        }
        else if(operator === '*') {
            result = first * second;
            return result;
        }
        else if(operator === '/') {
            result = first / second;
            return result;
        }
        
        if(operator === '=') {
            return second;
        }

        return second;
    }


    function displayResult() { // updates the output value on the display
        const display = document.querySelector('.calcDisplay');
        display.value = calculator.displayValue;
    }

    displayResult();

    const keys = document.querySelector('.calcKeys');
    keys.addEventListener('click', (event) => {
        const target = event.target; // clicked element

        // check what button clicked element is

        if(!target.matches('button')) { // terminate function if clicked elem is not a button
            return; 
        }
        if(target.classList.contains('operator')) {
            operators(target.value);
            displayResult();
            return;
        }

        if(target.classList.contains('decimal')) {
            inputDecimal(target.value);
            displayResult();
            return;
        }

        if(target.classList.contains('allClear')) {
            clearAll();
            displayResult();
            return;
        }

        inputNumbers(target.value);
        displayResult();
    });